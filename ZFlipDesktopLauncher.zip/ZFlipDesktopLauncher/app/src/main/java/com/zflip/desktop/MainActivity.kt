package com.zflip.desktop

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.key.*
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Night = Color(0xFF080D1B)
private val Panel = Color(0xD91A2540)
private val Cyan = Color(0xFF66E6FF)
private val Purple = Color(0xFF9C83FF)
private val Muted = Color(0xFF9AAAC8)

data class LaunchApp(val label: String, val packageName: String, val icon: android.graphics.drawable.Drawable, val isGame: Boolean)

class MainActivity : ComponentActivity() {
    private val openFile = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        uri?.let { runCatching { contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION) } }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { DesktopShell(onOpenFiles = { openFile.launch(arrayOf("*/*")) }) }
    }

    @Composable
    private fun DesktopShell(onOpenFiles: () -> Unit) {
        val context = LocalContext.current
        var page by remember { mutableStateOf("Início") }
        var search by remember { mutableStateOf("") }
        var activeWindow by remember { mutableStateOf<String?>(null) }
        var showPower by remember { mutableStateOf(false) }
        var windowX by remember { mutableFloatStateOf(18f) }
        var windowY by remember { mutableFloatStateOf(100f) }
        var windowWidth by remember { mutableFloatStateOf(340f) }
        var windowHeight by remember { mutableFloatStateOf(360f) }
        val prefs = remember { context.getSharedPreferences("zflip_desktop", MODE_PRIVATE) }
        var note by remember { mutableStateOf(prefs.getString("quick_note", "Bem-vindo ao Z Flip Desktop!\n\nSuas notas ficam salvas neste aparelho.") ?: "") }
        val apps = remember { loadApps() }
        val visibleApps = apps.filter { it.label.contains(search, true) || search.isBlank() }
        val games = apps.filter { it.isGame }
        val time = remember { mutableStateOf(now()) }
        BackHandler(enabled = activeWindow != null || page != "Início") {
            if (activeWindow != null) activeWindow = null else page = "Início"
        }

        MaterialTheme(colorScheme = darkColorScheme(primary = Cyan, background = Night, surface = Panel)) {
            Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(Color(0xFF101A35), Night, Color(0xFF251B4A))))) {
                Column(Modifier.fillMaxSize().padding(12.dp)) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(38.dp).clip(RoundedCornerShape(13.dp)).background(Brush.linearGradient(listOf(Cyan, Purple))), contentAlignment = Alignment.Center) {
                                Icon(Icons.Default.Terminal, null, tint = Night)
                            }
                            Spacer(Modifier.width(10.dp))
                            Column {
                                Text("Z FLIP", color = Color.White, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
                                Text("DESKTOP // NEON EDITION", color = Cyan, fontSize = 9.sp, letterSpacing = 1.5.sp)
                            }
                        }
                        Text(time.value, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    }
                    Spacer(Modifier.height(14.dp))
                    Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Column(Modifier.width(64.dp).fillMaxHeight().clip(RoundedCornerShape(22.dp)).background(Panel).padding(vertical = 10.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            SideButton(Icons.Default.Home, "Início", page == "Início") { page = "Início" }
                            SideButton(Icons.Default.GridView, "Apps", page == "Apps") { page = "Apps" }
                            SideButton(Icons.Default.SportsEsports, "Jogos", page == "Jogos") { page = "Jogos" }
                            SideButton(Icons.Default.Folder, "Arquivos", page == "Arquivos") { page = "Arquivos"; onOpenFiles() }
                            Spacer(Modifier.weight(1f))
                            SideButton(Icons.Default.Settings, "Sistema", page == "Sistema") { page = "Sistema" }
                            SideButton(Icons.Default.PowerSettingsNew, "Energia", false) { showPower = true }
                        }
                        Column(Modifier.weight(1f).fillMaxHeight().verticalScroll(rememberScrollState())) {
                            when (page) {
                                "Início" -> {
                                    Text("Seu espaço. Suas regras.", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                                    Text("Uma experiência desktop no seu Galaxy.", color = Muted, fontSize = 12.sp)
                                    Spacer(Modifier.height(16.dp))
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        InfoCard("DISPOSITIVO", "Galaxy Z Flip5", Icons.Default.Smartphone, Modifier.weight(1f))
                                        InfoCard("AMBIENTE", "Neon Desktop", Icons.Default.Bolt, Modifier.weight(1f))
                                    }
                                    Spacer(Modifier.height(16.dp))
                                    SectionTitle("ACESSO RÁPIDO", "Toque para abrir")
                                    val shortcuts = listOf(
                                        Triple("Todos os apps", Icons.Default.Apps, "Apps"),
                                        Triple("Meus arquivos", Icons.Default.FolderOpen, "Arquivos"),
                                        Triple("Central gamer", Icons.Default.SportsEsports, "Jogos"),
                                        Triple("Sistema", Icons.Default.Settings, "Sistema")
                                    )
                                    shortcuts.chunked(2).forEach { row ->
                                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 8.dp)) {
                                            row.forEach { item -> ShortcutCard(item.first, item.second, Modifier.weight(1f)) { page = item.third; if (item.third == "Arquivos") onOpenFiles() } }
                                            if (row.size == 1) Spacer(Modifier.weight(1f))
                                        }
                                    }
                                    Spacer(Modifier.height(18.dp))
                                    SectionTitle("JANELAS DE TRABALHO", "Simulação dentro do launcher")
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        WindowTile("Painel de notas", Icons.Default.Description, Modifier.weight(1f)) { activeWindow = "Painel de notas" }
                                        WindowTile("Monitor do sistema", Icons.Default.MonitorHeart, Modifier.weight(1f)) { activeWindow = "Monitor do sistema" }
                                    }
                                    Spacer(Modifier.height(14.dp))
                                    Text("DICA  •  Use teclado e mouse Bluetooth/USB para navegar. Defina Z Flip Desktop como app de início nas configurações do Android.", color = Muted, fontSize = 11.sp, lineHeight = 16.sp)
                                }
                                "Apps", "Jogos" -> {
                                    Text(if (page == "Jogos") "Central gamer" else "Aplicativos", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                                    Text(if (page == "Jogos") "Seus jogos instalados" else "Abra apps compatíveis instalados no aparelho", color = Muted, fontSize = 12.sp)
                                    Spacer(Modifier.height(12.dp))
                                    OutlinedTextField(value = search, onValueChange = { search = it }, modifier = Modifier.fillMaxWidth(), placeholder = { Text("Buscar aplicativo…") }, leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true, shape = RoundedCornerShape(16.dp), colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White, focusedBorderColor = Cyan, unfocusedBorderColor = Muted, focusedLeadingIconColor = Cyan, unfocusedLeadingIconColor = Muted))
                                    Spacer(Modifier.height(12.dp))
                                    val shown = (if (page == "Jogos") games else visibleApps).filter { it.label.contains(search, true) || search.isBlank() }
                                    if (shown.isEmpty()) Text("Nenhum app encontrado. Alguns apps do sistema podem ficar ocultos pelo Android.", color = Muted, modifier = Modifier.padding(12.dp))
                                    LazyVerticalGrid(columns = GridCells.Adaptive(minSize = 94.dp), modifier = Modifier.heightIn(max = 600.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                        items(shown, key = { it.packageName }) { app -> AppTile(app) {
                                            runCatching { context.packageManager.getLaunchIntentForPackage(app.packageName)?.let { context.startActivity(it) } }
                                        } }
                                    }
                                }
                                "Arquivos" -> {
                                    Text("Explorador de arquivos", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                                    Text("Acesso usando o seletor seguro do Android", color = Muted, fontSize = 12.sp)
                                    Spacer(Modifier.height(16.dp))
                                    ShortcutCard("Escolher arquivo ou pasta", Icons.Default.FolderOpen, Modifier.fillMaxWidth()) { onOpenFiles() }
                                    Spacer(Modifier.height(8.dp))
                                    Text("O Android abrirá o seletor de documentos. O launcher não lê seus arquivos sem você escolher um item.", color = Muted, fontSize = 12.sp)
                                }
                                else -> {
                                    Text("Sistema", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                                    Text("Configurações rápidas do Z Flip Desktop", color = Muted, fontSize = 12.sp)
                                    Spacer(Modifier.height(14.dp))
                                    ShortcutCard("Abrir configurações do Android", Icons.Default.Settings, Modifier.fillMaxWidth()) { runCatching { context.startActivity(Intent(android.provider.Settings.ACTION_SETTINGS)) } }
                                    Spacer(Modifier.height(8.dp))
                                    ShortcutCard("Escolher app de início padrão", Icons.Default.Home, Modifier.fillMaxWidth()) { runCatching { context.startActivity(Intent(android.provider.Settings.ACTION_HOME_SETTINGS)) } }
                                    Spacer(Modifier.height(12.dp))
                                    Text("Este projeto cria uma interface desktop no app. Janelas reais de outros aplicativos dependem dos recursos do Android/Samsung; aqui as janelas demonstrativas são internas.", color = Muted, fontSize = 12.sp, lineHeight = 17.sp)
                                }
                            }
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Color(0xE61A2540)).padding(horizontal = 12.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Circle, null, tint = Color(0xFF62F6B5), modifier = Modifier.size(8.dp))
                            Text("DESKTOP READY", color = Muted, fontSize = 9.sp, letterSpacing = 1.sp)
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                            DockIcon(Icons.Default.Home, "Início") { page = "Início" }
                            DockIcon(Icons.Default.Apps, "Apps") { page = "Apps" }
                            DockIcon(Icons.Default.Folder, "Arquivos") { page = "Arquivos"; onOpenFiles() }
                            DockIcon(Icons.Default.SportsEsports, "Jogos") { page = "Jogos" }
                        }
                        Text("ZFLIP OS", color = Cyan, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    }
                }
                if (activeWindow != null) {
                    BoxWithConstraints(Modifier.fillMaxSize().background(Color(0x66050A14))) {
                        val maxW = maxWidth.value
                        val maxH = maxHeight.value
                        val density = LocalDensity.current.density
                        val safeWidth = windowWidth.coerceIn(260f, maxW.coerceAtLeast(260f))
                        val safeHeight = windowHeight.coerceIn(230f, maxH.coerceAtLeast(230f))
                        Column(
                            Modifier.offset { IntOffset((windowX * density).toInt(), (windowY * density).toInt()) }
                                .width(safeWidth.dp).height(safeHeight.dp)
                                .clip(RoundedCornerShape(18.dp)).background(Color(0xFF17233D))
                                .padding(12.dp)
                        ) {
                            Row(
                                Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
                                    .background(Color(0xFF223354))
                                    .pointerInput(activeWindow) {
                                        detectDragGestures { change, dragAmount ->
                                            change.consume()
                                            windowX = (windowX + dragAmount.x / density).coerceIn(0f, (maxW - safeWidth).coerceAtLeast(0f))
                                            windowY = (windowY + dragAmount.y / density).coerceIn(0f, (maxH - safeHeight).coerceAtLeast(0f))
                                        }
                                    }.padding(start = 10.dp, end = 2.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(if (activeWindow == "Painel de notas") Icons.Default.Description else Icons.Default.MonitorHeart, null, tint = Cyan)
                                Spacer(Modifier.width(8.dp)); Text(activeWindow!!, color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                                IconButton(onClick = { activeWindow = null }) { Icon(Icons.Default.Close, null, tint = Color.White) }
                            }
                            Spacer(Modifier.height(10.dp))
                            if (activeWindow == "Painel de notas") {
                                OutlinedTextField(
                                    value = note,
                                    onValueChange = { note = it; prefs.edit().putString("quick_note", it).apply() },
                                    modifier = Modifier.fillMaxWidth().weight(1f),
                                    label = { Text("Notas rápidas") },
                                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White, focusedBorderColor = Cyan, unfocusedBorderColor = Muted)
                                )
                            } else {
                                Text("Monitor local", color = Cyan, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                                Text("Apps encontrados: ${apps.size}\nJogos detectados: ${games.size}\n\nEste painel não mede temperatura nem uso real de CPU.", color = Muted, modifier = Modifier.padding(top = 8.dp), lineHeight = 20.sp)
                            }
                            Spacer(Modifier.height(4.dp))
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End, verticalAlignment = Alignment.CenterVertically) {
                                Text("Arraste o topo para mover", color = Muted, fontSize = 9.sp)
                                Spacer(Modifier.width(8.dp))
                                Box(
                                    Modifier.size(28.dp).clip(RoundedCornerShape(8.dp)).background(Color(0x334EDCF5))
                                        .pointerInput(activeWindow) {
                                            detectDragGestures { change, dragAmount ->
                                                change.consume()
                                                windowWidth = (windowWidth + dragAmount.x / density).coerceIn(260f, (maxW - windowX).coerceAtLeast(260f))
                                                windowHeight = (windowHeight + dragAmount.y / density).coerceIn(230f, (maxH - windowY).coerceAtLeast(230f))
                                            }
                                        }, contentAlignment = Alignment.Center
                                ) { Icon(Icons.Default.OpenInFull, "Redimensionar", tint = Cyan, modifier = Modifier.size(16.dp)) }
                            }
                        }
                    }
                }
                if (showPower) AlertDialog(onDismissRequest = { showPower = false }, title = { Text("Menu do sistema") }, text = { Text("O Android controla desligamento e reinicialização. O launcher não executa essas ações diretamente.") }, confirmButton = { TextButton(onClick = { showPower = false }) { Text("Entendi") } }, containerColor = Color(0xFF17233D), titleContentColor = Color.White, textContentColor = Muted)
            }
        }
    }

    private fun loadApps(): List<LaunchApp> {
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN, null).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(intent, PackageManager.ResolveInfoFlags.of(0)).mapNotNull { ri: ResolveInfo ->
            val label = ri.loadLabel(pm)?.toString() ?: return@mapNotNull null
            val pkg = ri.activityInfo?.packageName ?: return@mapNotNull null
            val name = label.lowercase(Locale.getDefault())
            LaunchApp(label, pkg, ri.loadIcon(pm), listOf("game", "jogo", "play", "craft", "racing", "racing", "free fire", "blood strike", "efootball", "pubg", "minecraft", "roblox", "gta").any { name.contains(it) || pkg.lowercase().contains(it.replace(" ", "")) })
        }.distinctBy { it.packageName }.sortedBy { it.label.lowercase(Locale.getDefault()) }
    }

    private fun now(): String = SimpleDateFormat("EEE, HH:mm", Locale("pt", "BR")).format(Date())

    @Composable private fun SideButton(icon: ImageVector, label: String, selected: Boolean, onClick: () -> Unit) {
        Column(Modifier.width(58.dp).clip(RoundedCornerShape(15.dp)).background(if (selected) Color(0x334EDCF5) else Color.Transparent).clickable(onClick = onClick).padding(vertical = 9.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(icon, null, tint = if (selected) Cyan else Muted, modifier = Modifier.size(21.dp))
            Spacer(Modifier.height(4.dp)); Text(label, color = if (selected) Color.White else Muted, fontSize = 9.sp, maxLines = 1)
        }
    }
    @Composable private fun InfoCard(title: String, value: String, icon: ImageVector, modifier: Modifier = Modifier) {
        Column(modifier.clip(RoundedCornerShape(18.dp)).background(Panel).padding(12.dp)) {
            Icon(icon, null, tint = Cyan, modifier = Modifier.size(20.dp)); Spacer(Modifier.height(8.dp))
            Text(title, color = Muted, fontSize = 9.sp, letterSpacing = 1.sp); Text(value, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
    @Composable private fun SectionTitle(title: String, subtitle: String) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp, letterSpacing = 1.sp)
            Text(subtitle, color = Muted, fontSize = 9.sp)
        }
    }
    @Composable private fun ShortcutCard(title: String, icon: ImageVector, modifier: Modifier = Modifier, onClick: () -> Unit) {
        Row(modifier.clip(RoundedCornerShape(17.dp)).background(Panel).clickable(onClick = onClick).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(38.dp).clip(RoundedCornerShape(12.dp)).background(Color(0x264EDCF5)), contentAlignment = Alignment.Center) { Icon(icon, null, tint = Cyan) }
            Spacer(Modifier.width(10.dp)); Text(title, color = Color.White, fontWeight = FontWeight.Medium, fontSize = 12.sp, modifier = Modifier.weight(1f)); Icon(Icons.Default.ChevronRight, null, tint = Muted)
        }
    }
    @Composable private fun WindowTile(title: String, icon: ImageVector, modifier: Modifier = Modifier, onClick: () -> Unit) {
        Column(modifier.clip(RoundedCornerShape(17.dp)).background(Brush.linearGradient(listOf(Color(0xFF25365B), Panel))).clickable(onClick = onClick).padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) { Icon(icon, null, tint = Purple); Spacer(Modifier.width(6.dp)); Text("JANELA", color = Muted, fontSize = 8.sp, letterSpacing = 1.sp) }
            Spacer(Modifier.height(10.dp)); Text(title, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            Text("Abrir painel  ↗", color = Cyan, fontSize = 10.sp, modifier = Modifier.padding(top = 6.dp))
        }
    }
    @Composable private fun AppTile(app: LaunchApp, onClick: () -> Unit) {
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(17.dp)).background(Panel).clickable(onClick = onClick).padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            androidx.compose.foundation.Image(bitmap = androidx.compose.ui.graphics.asImageBitmap(app.icon.toBitmapCompat()), contentDescription = app.label, modifier = Modifier.size(40.dp))
            Spacer(Modifier.height(7.dp)); Text(app.label, color = Color.White, fontSize = 10.sp, maxLines = 2, minLines = 2, overflow = TextOverflow.Ellipsis, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
        }
    }
    @Composable private fun DockIcon(icon: ImageVector, label: String, onClick: () -> Unit) {
        Box(Modifier.size(34.dp).clip(RoundedCornerShape(11.dp)).background(Color(0x263FDFEF)).clickable(onClick = onClick), contentAlignment = Alignment.Center) { Icon(icon, label, tint = Color.White, modifier = Modifier.size(18.dp)) }
    }
}

private fun android.graphics.drawable.Drawable.toBitmapCompat(): android.graphics.Bitmap {
    val width = if (intrinsicWidth > 0) intrinsicWidth else 96
    val height = if (intrinsicHeight > 0) intrinsicHeight else 96
    val bitmap = android.graphics.Bitmap.createBitmap(width.coerceAtMost(192), height.coerceAtMost(192), android.graphics.Bitmap.Config.ARGB_8888)
    val canvas = android.graphics.Canvas(bitmap)
    setBounds(0, 0, canvas.width, canvas.height)
    draw(canvas)
    return bitmap
}
