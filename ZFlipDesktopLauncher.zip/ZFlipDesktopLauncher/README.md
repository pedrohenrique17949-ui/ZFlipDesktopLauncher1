# Z Flip Desktop Launcher

Projeto Android nativo em Kotlin + Jetpack Compose, pensado para o Samsung Galaxy Z Flip5.

## Recursos incluídos
- Interface futurista inspirada em desktop/DeX, com dock, navegação lateral e cards.
- Lista de apps que declaram atividade de launcher e abertura de aplicativos.
- Área de jogos com detecção heurística pelo nome do app/pacote (não é uma classificação perfeita).
- Atalhos para apps e configurações do Android.
- Seletor de arquivos do sistema (`ACTION_OPEN_DOCUMENT`), sem varrer o armazenamento.
- Janelas demonstrativas internas (notas e monitor) que podem ser arrastadas pela barra superior e redimensionadas pelo canto inferior; notas rápidas são salvas localmente. Navegação por toque e uso de mouse/teclado para controles compatíveis.
- Pode ser escolhido como aplicativo de início padrão no Android.

## Como gerar o APK
1. Instale o Android Studio atual em um computador.
2. Descompacte este ZIP e abra a pasta `ZFlipDesktopLauncher` no Android Studio.
3. Aguarde a sincronização do Gradle e instale os componentes de SDK solicitados.
4. Use **Build > Build APK(s)**.
5. O APK de debug normalmente aparece em `app/build/outputs/apk/debug/app-debug.apk`.
6. Transfira o APK para o Z Flip5 e instale-o, autorizando a instalação para o app de arquivos/navegador usado.
7. Para usá-lo como tela inicial: Configurações do Android > Aplicativos > Aplicativos padrão > App de início (o nome exato pode variar) > Z Flip Desktop.

## Requisitos e limitações reais
- `minSdk 26` (Android 8.0+) e compile/target SDK 35.
- O projeto fornece o código-fonte; nenhum APK pré-compilado foi produzido neste ambiente.
- O launcher não substitui Samsung DeX nem cria janelas flutuantes de outros apps por conta própria. As janelas no app são demonstrações internas. A abertura de apps ocorre no modo e nas janelas permitidos pelo Android/One UI.
- Não há garantia de saída DeX por USB-C no Z Flip5; esse recurso depende do suporte do aparelho/firmware. Use teclado/mouse Bluetooth ou USB-C OTG compatível.
- A lista de jogos usa palavras-chave e pode classificar incorretamente alguns aplicativos.
- A lista de apps respeita a visibilidade de pacotes do Android; apps ocultos pelo sistema podem não aparecer.
- O relógio é atualizado ao recriar a tela, não é um relógio contínuo em tempo real.
- As janelas redimensionáveis são internas ao launcher e não podem conter outros apps Android como se fossem janelas do Windows.
- Não é afiliado à Samsung e não usa marcas/ativos proprietários da Samsung além da referência de compatibilidade.

## Estrutura
- `app/src/main/java/com/zflip/desktop/MainActivity.kt`: interface e lógica principal.
- `app/src/main/AndroidManifest.xml`: declara a atividade como app normal e opção de HOME.
- `app/build.gradle.kts`: dependências e configurações de compilação.
